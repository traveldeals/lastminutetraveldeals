<!DOCTYPE html>
<html lang="en">
<head>
<title>www.cheapesthotelrates.info - Contact Us</title>
<meta charset="utf-8">
<link rel="stylesheet" href="images/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="images/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="images/style.css" type="text/css" media="all">
<script type="text/javascript" src="images/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="images/cufon-yui.js"></script>
<script type="text/javascript" src="images/cufon-replace.js"></script>
<script type="text/javascript" src="images/Alte_Haas_Grotesk_400.font.js"></script>
<script type="text/javascript" src="images/Alte_Haas_Grotesk_700.font.js"></script>
<script type="text/javascript" src="images/jquery.faded.js"></script>
<script type="text/javascript" src="images/jquery.jqtransform.js"></script>
<script type="text/javascript" src="images/script.js"></script>
<!--[if lt IE 7]>
   <script type="text/javascript" src="images/ie6_script_other.js"></script>
 <![endif]-->
<!--[if lt IE 9]>
  	<script type="text/javascript" src="images/html5.js"></script>
  <![endif]-->
</head>
<body id="page1">
<div class="slider-wrap">
  <div id="faded">
      <div class="rap"> <img src="images/slide-img1.jpg"> <img src="images/slide-img2.jpg"> <img src="images/slide-img3.jpg"> <img src="images/slide-img4.jpg"> <img src="images/slide-img5.jpg"> </div>
   </div>
</div>
<div id="main">
   <!-- header -->
   <header>
      <h1><a href="#">Travel Guide</a></h1>
     <nav>
         <ul>
            <li><a href="http://www.cheapesthotelrates.info">Home</a></li>
            <li><a href="http://search.cheapesthotelrates.info">Hotels Deals</a></li>
            <li><a href="http://www.cheapesthotelrates.info/flights.html">Flights Deals</a></li>
            <li><a href="http://www.cheapesthotelrates.info/aboutus.html">About Us</a></li>
            <li class="current"><a href="http://www.cheapesthotelrates.info/contactus.php">Contact Us</a></li>
         </ul>
      </nav>
      
   </header>
   <!-- content -->
   <section id="content">
     <div class="line-ver1"></div>
     <div class="wrap" style="overflow:auto;">
    <table width="400" border="0" align="center" cellpadding="3" cellspacing="1">
<tr>
<td><strong>Contact Form </strong></td>
</tr>
</table>
      <table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="send_contact.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td width="16%">Subject</td>
<td width="2%">:</td>
<td width="82%"><input name="subject" type="text" id="subject" size="50"></td>
</tr>
<tr>
<td>Detail</td>
<td>:</td>
<td><textarea name="detail" cols="50" rows="4" id="detail"></textarea></td>
</tr>
<tr>
<td>Name</td>
<td>:</td>
<td><input name="name" type="text" id="name" size="50"></td>
</tr>
<tr>
<td>Email</td>
<td>:</td>
<td><input name="customer_mail" type="text" id="customer_mail" size="50"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Submit"> <input type="reset" name="Submit2" value="Reset"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
        </div>
  </section>
   
<!-- aside -->
   <aside>
      <div class="container">
         <div class="inside"><strong><a href="http://www.cheapesthotelrates.info">cheapest hotel rates</a> © 2014    |   All Rights Reserved. </strong></div>
      </div>
   </aside>
   <!-- footer -->
   <footer></footer>
</div>
<script type="text/javascript"> Cufon.now(); </script>

</body>
</html>
