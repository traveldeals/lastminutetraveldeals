$(function(){
	$(".anythingSlider .wrapper li").hover(function(){
		$(this).find("p.price em").hide();																						
		$(this).find("p.price span").fadeIn("fast");
	}, function(){
		$(this).find("p.price span").hide();																						
		$(this).find("p.price em").fadeIn("fast");
	});
})