Cufon.replace(' #nav ul li a', { fontFamily: 'Bebas', hover:true });
Cufon.replace('h2', { fontFamily: 'Aardvark', textShadow: '2px 2px 4px #0f76d6'});
Cufon.replace('.link1', { fontFamily: 'BrushScript BT', hover:true});