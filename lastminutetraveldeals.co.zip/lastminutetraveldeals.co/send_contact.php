<!DOCTYPE html>
<html lang="en">
<head>
<title>lastminutetraveldeals.co - Thank You</title>
<meta charset="utf-8">
<link rel="stylesheet" href="images/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="images/layout.css" type="text/css" media="all">
<link rel="stylesheet" href="images/style.css" type="text/css" media="all">
<script type="text/javascript" src="images/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="images/cufon-yui.js"></script>
<script type="text/javascript" src="images/cufon-replace.js"></script>
<script type="text/javascript" src="images/Alte_Haas_Grotesk_400.font.js"></script>
<script type="text/javascript" src="images/Alte_Haas_Grotesk_700.font.js"></script>
<script type="text/javascript" src="images/jquery.faded.js"></script>
<script type="text/javascript" src="images/jquery.jqtransform.js"></script>
<script type="text/javascript" src="images/script.js"></script>
<!--[if lt IE 7]>
   <script type="text/javascript" src="images/ie6_script_other.js"></script>
 <![endif]-->
<!--[if lt IE 9]>
  	<script type="text/javascript" src="images/html5.js"></script>
  <![endif]-->
</head>
<body id="page1">
<div class="slider-wrap">
  <div id="faded">
      <div class="rap"> <img src="images/slide-img1.jpg"> <img src="images/slide-img2.jpg"> <img src="images/slide-img3.jpg"> <img src="images/slide-img4.jpg"> <img src="images/slide-img5.jpg"> </div>
   </div>
</div>
<div id="main">
   <!-- header -->
  <header>
      <h1><a href="#">Travel Guide</a></h1>
     <nav>
         <ul>
            <li><a href="http://www.lastminutetraveldeals.co">Home</a></li>
            <li><a href="http://search.lastminutetraveldeals.co">Hotels Deals</a></li>
            <li><a href="http://www.lastminutetraveldeals.co/flights.html">Flights Deals</a></li>
            <li><a href="http://www.lastminutetraveldeals.co/aboutus.html">About Us</a></li>
            <li class="current"><a href="http://www.lastminutetraveldeals.co/contact.php">Contact Us</a></li>
         </ul>
      </nav>
      <div class="header-box">
      <iframe frameborder="0" style="display:block;" width="200px" height="190px" src="http://www.hotelscombined.com/Affiliate/Widgets/200x190_b/default.aspx?a_aid=36839&languageCode=EN" scrolling="no" allowtransparency="true" ></iframe>
      </div>
   </header>
   <!-- content -->
   <section id="content">
     <div class="line-ver1"></div>
     <div class="wrap" style="overflow:auto;">
<center>    <?php
// Contact subject
$subject ="$subject";
// Details
$message="$detail";

// Mail of sender
$mail_from="$customer_mail";
// From
$header="from: $name <$mail_from>";

// Enter your email address
$to ='amin.src@gmail.com';

$send_contact=mail($to,$subject,$message,$header);

// Check, if message sent to your email
// display message "We've recived your information"
if($send_contact){
echo "We've recived your query, We will contact you shortly. Thank You for choosing www.lastminutetraveldeals.co";
}
else {
echo "ERROR";
}
?></center>
     </div>
  </section>
   
<!-- aside -->
   <aside>
      <div class="container">
         <div class="inside"><strong><a href="http://www.lastminutetraveldeals.co">lastminutetraveldeals.co</a> © 2018    |   All Rights Reserved. </strong></div>
      </div>
   </aside>
   <!-- footer -->
   <footer></footer>
</div>
<script type="text/javascript"> Cufon.now(); </script>

</body>
</html>
